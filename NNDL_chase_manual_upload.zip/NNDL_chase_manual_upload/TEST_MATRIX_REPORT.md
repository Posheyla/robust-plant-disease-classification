# Plant Disease Classification Test Matrix Report

## Executive Summary

A comprehensive hyperparameter optimization study was conducted on a HOG (Histogram of Oriented Gradients) + Logistic Regression baseline model for plant disease classification across the PlantVillage dataset. The test matrix evaluated **192 distinct configurations** across four tunable parameters to identify optimal model performance. The best-performing configurations achieved **63.6% accuracy** on the color test set, with all top performers using the same image size (64×64 pixels) but varying regularization and convergence strategies.

---

## Methodology: Tunable Parameters Tested

### 1. **Image Size** (4 variants: 32, 48, 64, 96 pixels)
- **Purpose**: Controls input dimensionality and feature extraction resolution
- **Impact**: Larger images capture more fine-grained detail but increase computational cost and feature dimensionality
- **Finding**: 64×64 dominated the top 5 results, suggesting an optimal balance between detail and model generalization

### 2. **Tolerance (tol)** (4 variants: 0.001, 0.005, 0.01, 0.05)
- **Purpose**: Controls LogisticRegression convergence criterion; lower values = stricter convergence
- **Range**: 0.001 (strict/slow) to 0.05 (loose/fast)
- **Impact**: Critical tradeoff between optimization quality and training speed
  - **tol=0.05**: Quick convergence (55s), but may stop prematurely
  - **tol=0.01**: Moderate convergence (7s–344s depending on solver), more refined optimization
  - **tol=0.001**: Strictest convergence; longer training times
- **Finding**: Moderate tolerance (tol=0.01, 0.05) performed best; very loose tolerance (0.05) at 55s provided competitive accuracy

### 3. **Regularization Strength (C)** (4 variants: 0.1, 1.0, 5, 10.0)
- **Purpose**: Controls inverse regularization; higher C = less regularization (more model flexibility)
- **Range**: 0.1 (heavy regularization/underfitting) to 10.0 (light regularization/overfitting risk)
- **Impact**: Subtle but measurable effect on generalization
  - **C=0.1**: Strong regularization; may underfit
  - **C=1.0**: Moderate regularization; traditionally safe default
  - **C=5, 10.0**: Lighter regularization; may overfit but can capture complex patterns
- **Finding**: Top 2 configurations split between C=1.0 and C=10.0 identically (both 63.6%), suggesting diminishing returns beyond C=1.0 for this dataset size (29K training samples)

### 4. **Solver Algorithm** (3 variants: lbfgs, saga, liblinear)
- **Purpose**: Controls optimization algorithm used by LogisticRegression
- **Characteristics**:
  - **lbfgs**: Limited-memory BFGS; robust, second-order optimization; excellent for small-to-medium problems
  - **saga**: Stochastic average gradient; faster for large datasets, scales well
  - **liblinear**: Library for linear classification; fastest for simple problems; limited solver flexibility
- **Impact on Speed**: Dramatic differences observed
  - **lbfgs**: Fast convergence (7s per model)
  - **saga**: Highly variable (56s–344s); dependent on tolerance and dataset size
  - **liblinear**: Not in top 5
- **Finding**: **lbfgs** delivered competitive accuracy (63.6%) in 7 seconds, while saga variants required 55–344 seconds for equivalent or worse accuracy

---

## Results: Top 5 Performers

| Configuration | Image Size | Tolerance | C Value | Solver | Color Accuracy | Robustness Gap | Train Time |
|---|---|---|---|---|---|---|---|
| size64_tol0.050_C1.0_saga | 64 | 0.05 | 1.0 | saga | **63.65%** | 0.430 | 55.7s |
| size64_tol0.050_C10.0_saga | 64 | 0.05 | 10.0 | saga | **63.65%** | 0.430 | 56.2s |
| size64_tol0.010_C1.0_lbfgs | 64 | 0.01 | 1.0 | lbfgs | **63.57%** | 0.442 | 7.0s |
| size64_tol0.010_C10.0_lbfgs | 64 | 0.01 | 10.0 | lbfgs | **63.55%** | 0.442 | 7.0s |
| size64_tol0.010_C1.0_saga | 64 | 0.01 | 1.0 | saga | **63.08%** | 0.430 | 344.1s |

---

## Key Findings

### Winner: Tied Performance, Different Strategies
The top two configurations achieved identical **test_color_accuracy of 63.6%**:

1. **size64_tol0.050_C1.0_saga** (55.7s) — Loose tolerance + fast convergence
2. **size64_tol0.050_C10.0_saga** (56.2s) — Loose tolerance + reduced regularization

Both employ the **SAGA solver** with relaxed tolerance (0.05), trading longer training time (55s) for refined gradient optimization.

### Alternative Winner: Speed + Accuracy
**size64_tol0.010_C1.0_lbfgs** achieved **63.6% identical accuracy in 7 seconds** — an **8× speedup** over the saga leaders. For practical deployment, this represents exceptional efficiency.

### Robustness Gap Alert
A concerning **robustness gap** of 0.43 (43%) separates color test accuracy from segmented test accuracy:
- **Color accuracy**: 63.6%
- **Segmented accuracy**: ~19.6%

This indicates the model relies heavily on color features and struggles with segmentation-based leaf images. Feature engineering or dataset rebalancing may be needed to improve robustness.

### Image Size Sweet Spot
All top 5 configurations used **64×64 pixel images**. Larger or smaller sizes failed to appear in top performers, suggesting 64 pixels provides the right balance of feature richness without overfitting or underfitting.

---

## Recommendations

1. **For Production Use**: Adopt **lbfgs + tol=0.01 + C=1.0 + size64** as the production baseline
   - Fast training (7s per model)
   - Competitive accuracy (63.6%)
   - Robust optimization algorithm
   
2. **If Accuracy Is Critical**: Consider **saga + tol=0.05 + C=1.0 + size64** for marginal gains
   - Identical accuracy but 8× slower (56s)
   - May be warranted if inference serving is not latency-critical

3. **Address Robustness Gap**: Investigate why color-based models fail on segmented images
   - Augment training data with segmented variants
   - Engineer color-agnostic features (shape, texture, spatial patterns)
   - Consider ensemble methods combining color and segmentation

4. **Future Optimization**: Test CNN baselines (via `train.py`) to potentially exceed 63.6% and improve robustness gap

---

## Technical Summary

| Metric | Value |
|--------|-------|
| **Total Configurations Tested** | 192 |
| **Best Test Accuracy** | 63.6% |
| **Optimal Image Size** | 64×64 pixels |
| **Recommended Solver** | lbfgs (speed) or saga (refinement) |
| **Recommended Tolerance** | 0.01–0.05 |
| **Recommended C Value** | 1.0 |
| **Training Time Range** | 7–344 seconds |
| **Robustness Gap (Color vs. Segmented)** | 43% |
| **Feature Extraction Method** | HOG (Histogram of Oriented Gradients) |
